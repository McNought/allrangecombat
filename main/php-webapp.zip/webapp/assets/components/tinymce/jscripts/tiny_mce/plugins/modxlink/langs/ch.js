tinyMCE.addI18n('ch.modxlink',{
    link_desc:"Insert/edit link"
});