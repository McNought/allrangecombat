tinyMCE.addI18n('br.modxlink',{
    link_desc:"Insert/edit link"
});