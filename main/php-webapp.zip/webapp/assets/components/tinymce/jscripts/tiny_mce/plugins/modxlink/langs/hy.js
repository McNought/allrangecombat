tinyMCE.addI18n('hy.modxlink',{
    link_desc:"Insert/edit link"
});